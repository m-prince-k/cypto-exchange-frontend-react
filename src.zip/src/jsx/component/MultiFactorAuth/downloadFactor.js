import React from "react";

export default function DownloadFactor(){
    return (
        <>
        <div id="app_download" class="tab-pane fade active in">
<h3>Step <span class="numberCircle">1</span></h3>
<div class="mt-2">
<div class="row d-flex acenter jcenter step-mb-security">
<div class="col-xs-12 col-md-2">
<img src="https://moneyplantcx.com/resources/images/auth-ico.png" class="img-responsive max-100 m-auto" />
</div>
<div class="col-xs-12 col-md-5 pl-5">
<h5 class="codepatch">Download &amp; Install Google Authentication App</h5>
<div class="mt-3">
<a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8" alt="Apple APP Store" class="mr-1" target="_blank">
<img src="https://moneyplantcx.com/assets/images/appstorebutton.png" style="height:42px;" />
</a>
<a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2" target="_blank" alt="Googl Play Store">
<img src="https://moneyplantcx.com/assets/images/googlestorebutton.png" style="height:42px;" />
</a>
</div>
</div>
</div>
</div>
<div class="nxt_step mt-4 text-right">
<button type="button" onclick="moveToNext()" data-target="menu2" class="btn btn-primary">Next &gt;</button>
</div>
</div>
        </>
    )
}