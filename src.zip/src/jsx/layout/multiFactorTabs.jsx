import React from 'react';
import { Link } from 'react-router-dom';



export default function MultiFactorMenu() {

    return (
        <>
            <ul className="d-flex">
                <li className="nav-item">
                    <Link to="/downloadQrCode" className="nav-link">
                        <i className="mdi mdi-bullseye"></i>
                        <span>1. Download App</span>
                    </Link>
                </li>
                <li className="nav-item">
                    <Link to="/account-deposit" className="nav-link">
                        <i className="mdi mdi-heart"></i>
                        <span>2. Scan Qr Code</span>
                    </Link>
                </li>
                <li className="nav-item">
                    <Link to="/account-withdraw" className="nav-link">
                        <i className="mdi mdi-pentagon"></i>
                        <span>3. Backup Key</span>
                    </Link>
                </li>
                <li className="nav-item">
                    <Link to="/account-api" className="nav-link">
                        <i className="mdi mdi-database"></i>
                        <span>4. Enable Google 2FA</span>
                    </Link>
                </li>
            </ul>
        </>
    )
}