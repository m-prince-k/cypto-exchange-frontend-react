import { combineReducers } from "@reduxjs/toolkit";
import basicInfoSlice from "../BasicInfo/basicInfoSlice";
import orderMatchingSlice from "../order/orderMatchingSlice";

const rootReducer= combineReducers({
    basic:basicInfoSlice,
    order:orderMatchingSlice
})
export default rootReducer;