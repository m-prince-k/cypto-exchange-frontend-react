import { useRef,useEffect } from "react";
import {io} from "socket.io-client";

export const SocketConnection=() => {
    let socket=useRef();

   
      socket.current=io("ws://localhost:4000");
      socket.current.on("connection",(socket) => {
        console.log("connected to server");
      });
    return socket;
}